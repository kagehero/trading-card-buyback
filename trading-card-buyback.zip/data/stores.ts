import type { Store } from "@/types/store"

export const stores: Store[] = []
